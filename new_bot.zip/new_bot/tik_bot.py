from TikTokApi import TikTokApi
import string
import random
from pathlib import Path

# Generate a random device ID
did = ''.join(random.choice(string.digits) for num in range(19))

# Your actual verifyFp value (replace this with your real verifyFp)
verifyFp = "verify_k1lhjg5l_jkl3h4jkh45_HJkjhjkg_LsdfkHsdf"

api = TikTokApi.get_instance(custom_verifyFp=verifyFp, custom_did=did)

# Print the trending TikToks
print(api.trending())

# Change the line below
proxy_address = "https://www.tiktok.com/@dkshow7/video/7337023948120444165"
count = 100
tiktoks = api.trending(count=count, proxy_address=proxy_address)

# Create a directory for downloads if it doesn't exist
Path("downloads").mkdir(exist_ok=True)

# Download TikToks
for i in range(len(tiktoks)):
    data = api.get_Video_By_TikTok(tiktoks[i], proxy_address=proxy_address)
    with open("downloads/{}.mp4".format(str(i)), 'wb') as output:
        output.write(data)

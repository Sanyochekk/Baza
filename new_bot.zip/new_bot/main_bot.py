import telebot
import os
from config import *
from pytube import YouTube

bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=["start"])
def start_message(message):
    chat_id = message.chat.id
    bot.send_message(chat_id, "Привет, я умею скачивать видео с YouTube! \n"
                              "Отправь мне ссылку")

@bot.message_handler(func=lambda message: True)
def text_message(message):
    chat_id = message.chat.id
    url = message.text
    if url.startswith(("https://www.youtube.com/" or "https://youtu.be/")):
        yt = YouTube(url)
        bot.send_message(chat_id, f"*Начинаю загрузку видео*: {yt.title}\n"
                                  f"*С канала*: [{yt.author}]({yt.channel_url})", parse_mode="Markdown")
        # Call the download_youtube_video function
        bot.send_chat_action(chat_id, 'upload_video')
        bot.register_next_step_handler(message, download_youtube_video, url)
    else:
        bot.send_message(chat_id, "Некорректная ссылка. Пожалуйста, отправьте правильную ссылку на видео с YouTube.")

def download_youtube_video(message, url):
    try:
        yt = YouTube(url)
        stream = yt.streams.filter(progressive=True, file_extension="mp4").get_highest_resolution()
        video_path = f"{message.chat.id}/{message.chat.id}_{yt.title}.mp4"
        stream.download(video_path)

        with open(video_path, "rb") as video_file:
            bot.send_video(message.chat.id, video_file, caption="Вот ваше видео*", parse_mode="Markdown")

        os.remove(video_path)
    except Exception as e:
        bot.send_message(message.chat.id, f"Ошибка при скачивании или отправке видео: {str(e)}")


if __name__ == "__main__":
    bot.polling(none_stop=True, interval=0, timeout=20)

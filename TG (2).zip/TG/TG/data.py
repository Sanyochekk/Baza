
import sqlalchemy as db

engine = db.create_engine('sqlite:///my_db.db')

connection = engine.connect()

metadata = db.MetaData()

user = db.Table('User', metadata,
    db.Column('id', db.Integer, primary_key=True),
    db.Column('name', db.Text),
    db.Column('age', db.Text)
)


metadata.create_all(engine)

insert_query = user.insert().values([
    {"name": "OK","age":18},
    {"name": "man",'age':1.6},
])

connection.execute(insert_query)

select_query = db.select(user)
select_result = connection.execute(select_query)
print(select_result.fetchall())

products = db.Table('products', metadata,
        db.Column("product_id", db.Integer, primary_key = True),
        db.Column("product_name", db.Text),
        db.Column("supplier_name", db.Text),
        db.Column("price_per_tonne", db.Integer)
        )
metadata.create_all(engine)

insertion_query = products.insert().values([

])
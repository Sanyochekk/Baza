from config import TOKEN 
import telebot 
from telebot import types
from typing import List
from sqlalchemy import ForeignKey
from sqlalchemy import String
from typing import Optional
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy.orm import relationship
import sqlalchemy as db

bot = telebot.TeleBot(TOKEN) 
 
engine = db.creat_engine("sqlite:///products-sqlalchemy.db")

connection = engine.connect()

metadata = db.MetaData()

products = db.Table('products', metadata,
        db.Column("product_id", db.Integer, primary_key = True),
        db.Column("product_name", db.Text),
        db.Column("supplier_name", db.Text),
        db.Column("price_per_tonne", db.Integer)
        )
metadata.create_all(engine)

insertion_query = products.insert().values([

])









keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True) 
button_help = types.KeyboardButton('/Calculator') 
button_start = types.KeyboardButton('/start') 
button_art = types.KeyboardButton('/art') 
button_site = types.KeyboardButton('/Website') 
keyboard.add(button_help, button_start, button_art, button_site) 
 
inMenu1 = types.InlineKeyboardMarkup(row_width=4)  # Змінено row_width на 3 
inMenu2 = types.InlineKeyboardMarkup(row_width=4)  # Змінено row_width на 3
 
button_04 = types.InlineKeyboardButton(text="/", callback_data="-3") 
button_03 = types.InlineKeyboardButton(text="%", callback_data="-2") 
button_02 = types.InlineKeyboardButton(text="()", callback_data="-1") 
button_01 = types.InlineKeyboardButton(text="C", callback_data="4") 
button_1 = types.InlineKeyboardButton(text="7", callback_data="-3") 
button_2 = types.InlineKeyboardButton(text="8", callback_data="-2") 
button_3 = types.InlineKeyboardButton(text="9", callback_data="-1") 
button_4 = types.InlineKeyboardButton(text="*", callback_data="4") 
button_5 = types.InlineKeyboardButton(text="4", callback_data="5") 
button_6 = types.InlineKeyboardButton(text="5", callback_data="6") 
button_7 = types.InlineKeyboardButton(text="6", callback_data="7") 
button_8 = types.InlineKeyboardButton(text="-", callback_data="8") 
button_9 = types.InlineKeyboardButton(text="1", callback_data="9") 
button_10 = types.InlineKeyboardButton(text="2", callback_data="10") 
button_11= types.InlineKeyboardButton(text="3", callback_data="11") 
button_12 = types.InlineKeyboardButton(text="+", callback_data="12") 
button_13 = types.InlineKeyboardButton(text="0", callback_data="9") 
button_14 = types.InlineKeyboardButton(text=".", callback_data="10") 
button_15= types.InlineKeyboardButton(text="=", callback_data="11") 

 
inMenu1.add(button_01,button_02,button_03,button_04,button_1, button_2, button_3,button_4,button_5,button_6,button_7,button_8,button_9,button_10,button_11,button_12,button_13,button_14,button_15,)
 
 
# Обробник для кнопки "/help" 
@bot.message_handler(commands=['Calculator']) 
def help_command(message): 
    bot.send_message(message.chat.id, ("Калькулятор Бот - це зручний і простий у використанні калькулятор, який доступний прямо в Телеграмі."
                                       "Завдяки йому ви можете швидко та легко виконувати різні математичні обчислення безпосередньо в чаті."), reply_markup=inMenu1)
@bot.message_handler(commands=['Website']) 
def Website_command(message): 
    bot.send_message(message.chat.id, ("Калькулятор Бот - це зручний і простий у використанні калькулятор, який доступний прямо в Телеграмі."
                                       "Завдяки йому ви можете швидко та легко виконувати різні математичні обчислення безпосередньо в чаті."), reply_markup=inMenu1)

 
# Обробник для команди /start 
@bot.message_handler(commands=['start']) 
def start(message): 
    greeting_message = ( 
        "Привіт! 👋 Я тут, щоб тобі допомогти! Я можу відповідати на запитання, " 
        "надавати інформацію, виконувати команди та багато іншого. Просто напиши мені, і давай почнемо!" 
    ) 
    bot.send_sticker(message.chat.id, "CAACAgIAAxkBAAEK4iZlbDif-7TiYrN8l1Jp_7nQ6cswWwAC9wEAAhZCawo59nBvtGN_xDME") 
    bot.send_message(message.chat.id, greeting_message, reply_markup=keyboard) 

 
# Обробник для стікерів 
@bot.message_handler(content_types=['sticker']) 
def sticker_handler(message): 
    target_sticker_id = "CAACAgIAAxkBAAEKx_xlWlCFjoeRqEH5fP3FWpckS24MgQACpR0AAlJicEt4rpAfxbmvdTME" 
    sticker_id = message.sticker.file_id 
 
    if sticker_id == target_sticker_id: 
        bot.send_message(message.chat.id, f"Ви відправили стікер з ID: {sticker_id}") 
        bot.send_sticker(message.chat.id, "CAACAgIAAxkBAAEKx_xlWlCFjoeRqEH5fP3FWpckS24MgQACpR0AAlJicEt4rpAfxbmvdTME") 
        bot.send_sticker(message.chat.id, sticker_id) 
    else: 
        bot.send_message(message.chat.id, f"ID стікера: {sticker_id}") 
 
# Обробник для Inline-відповідей 
@bot.callback_query_handler(func=lambda call: True) 
def callback_handler(call): 
    # Тут можна обробляти Inline-відповіді, якщо необхідно 
    pass 
 
# Запуск бота 
bot.polling(none_stop=True)
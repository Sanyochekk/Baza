import telebot
from telebot.types import InputMediaVideo
import os
from config import *
from pytube import YouTube
from io import BytesIO

bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start'])
def start_message(message):
    bot.send_message(message.chat.id, "Привет, я умею скачивать видео с YouTube! \n"
                                      "Отправь мне силку")

@bot.message_handler(func=lambda message: True)
def text_message(message):
    url = message.text
    if url.startswith(("https://www.youtube.com/" or "https://youtu.be/")):
        try:
            yt = YouTube(url)
            stream = yt.streams.filter(progressive=True, file_extension="mp4").get_highest_resolution()
            buffer = BytesIO()
            stream.stream_to_buffer(buffer)
            file = buffer.getvalue()
            bot.send_video(message.chat.id, file, caption=f"*Начинаю загрузку видео*: {yt.title}\n"
                                                          f"*С канала*: [{yt.author}]({yt.channel_url})", parse_mode="Markdown")
        except Exception as e:
            bot.reply_to(message, f"Ошибка при скачивании или отправке видео: {str(e)}")
    else:
        bot.reply_to(message, "в")

if __name__ == "__main__":
    bot.polling()

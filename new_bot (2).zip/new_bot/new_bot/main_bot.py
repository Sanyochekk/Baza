from aiogram import Bot, Dispatcher, Router, types
from aiogram.filters import CommandStart
from aiogram.enums import ParseMode
from aiogram.types import Message
from aiogram.types import BufferedInputFile
from io import BytesIO
import asyncio
import os
from config import *
from pytube import YouTube

bot = Dispatcher()

@bot.message(CommandStart())
async def start_message(message: Message):
    await message.answer("Привет, я умею скачивать видео с YouTube! \n"
                              "Отправь мне ссылку")

@bot.message()
async def text_message(message: Message):
    url = message.text
    if url.startswith(("https://www.youtube.com/" or "https://youtu.be/")):
        yt = YouTube(url)
        await message.answer(f"*Начинаю загрузку видео*: {yt.title}\n"
                                  f"*С канала*: [{yt.author}]({yt.channel_url})", parse_mode="Markdown")
        # Call the download_youtube_video function
        # bot.send_chat_action(chat_id, 'upload_video')
        await download_youtube_video(message, url)

    else:
        message.answer("Некорректная ссылка. Пожалуйста, отправьте правильную ссылку на видео с YouTube.")

async def download_youtube_video(message:Message, url):
    try:
        yt = YouTube(url)
        stream = yt.streams.filter(progressive=True, file_extension="mp4").get_highest_resolution()
        buffer = BytesIO()
        stream.stream_to_buffer(buffer)
        file = BufferedInputFile(buffer.getvalue(), yt.title)
        await message.answer_video(file)
    except Exception as e:
        message.answer(f"Ошибка при скачивании или отправке видео: {str(e)}")


async def main() -> None:
    # Initialize Bot instance with a default parse mode which will be passed to all API calls
    bot_start = Bot(TOKEN)
    # And the run events dispatching
    await bot.start_polling(bot_start)


if __name__ == "__main__":
    asyncio.run(main())
